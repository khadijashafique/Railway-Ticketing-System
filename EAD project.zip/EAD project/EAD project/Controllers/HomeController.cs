﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EAD_project.Models;

namespace EAD_project.Controllers
{
    public class HomeController : Controller
    {
        //
       

        //object of datacontext to access data from database
        TrainDataClassDataContext td=new TrainDataClassDataContext();

        // GET: /Home/
        public ActionResult Index()
        {
           
            
            return View();
        }


       //controller for Edit Train Functionality
        public ActionResult EditTrain()
        {

            return View();
        }
[HttpPost]
        public ActionResult EditTrain(trainData model)
        {
              if(model.Id>=0)
              {
                  try
                  {
                      var select = td.TrainInfos.First(t => t.Id == model.Id);
                      TempData["message"] = select;
                     
                    
                    return RedirectToAction("EditTrainSubmission");
                  }
                  catch(Exception ex)
                  {
                      ViewBag.IdNotFound = string.Format("Data of this Id {0} is not found",model.Id);
                      return View(model);
                  }
                  
              }
            return View(model);
        }


       public ActionResult EditTrainSubmission()
        {
            return View();
        }

       public ActionResult SubmitChanges()
       {
           TrainInfo train = td.TrainInfos.First(s => s.Id == int.Parse(Request["Id"]));
           train.Train_Name = Request["Train_name"];
           train.Train_type = Request["Train_Type"];
           train.source_stn = Request["source_stn"];
           train.destination_stn = Request["destination_stn"];
           train.source_id = Request["source_id"];
           train.destination_id = Request["destination_id"];

           td.SubmitChanges();
           TempData["TrainEdited"] = string.Format("train of id {0} edited sucessfully", Request["Id"]);
           return RedirectToAction("EditTrain");
       }




        //controllers for displaying data of different type of classes
        public ActionResult AC_sleeper()
        {
            var select = td.TrainInfos.Where(t => t.Train_type.ToLower().Equals("ac sleeper"));
               return View(select);
        }

        public ActionResult AC_parlour_car()
        {
            var select = td.TrainInfos.Where(t => t.Train_type.ToLower().Equals("ac parlour car"));
            return View(select);
        }

        public ActionResult AC_Standard()
        {
            var select = td.TrainInfos.Where(t => t.Train_type.ToLower().Equals("ac standard"));
            return View(select);
        }

        public ActionResult First_Class_Sleeper()
        {
            var select = td.TrainInfos.Where(t => t.Train_type.ToLower().Equals("first class sleeper"));
            return View(select);
        }

        public ActionResult Economy_class()
        {
            var select = td.TrainInfos.Where(t => t.Train_type.ToLower().Equals("economy class"));
            return View(select);
        }

        public ActionResult Second_class()
        {
            var select = td.TrainInfos.Where(t => t.Train_type.ToLower().Equals("second class"));
            return View(select);
        }


        //controller to add train in database
        public ActionResult Train()
        {
            return View();
        }

         [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult  Train(trainData model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    TrainInfo info = new TrainInfo();
                    info.Train_Name = model.Name;
                    info.Train_type = model.Type;
                    info.source_stn = model.Source_station;
                    info.destination_stn = model.Destination_station;
                    info.source_id = model.Source_Id;
                    info.destination_id = model.Destination_id;


                    td.TrainInfos.InsertOnSubmit(info);
                    td.SubmitChanges();

                    model.Id = info.Id;
                    TempData["trainAdded"] = string.Format("train of id {0} added sucessfully", model.Id);


                    return RedirectToAction("Train");


                }
                catch (Exception e)
                {
                    ViewBag.TrainNotAdded = "Error! train not added";

                    return View(model);
                }
           }
            return View(model);
        }

    }
}
