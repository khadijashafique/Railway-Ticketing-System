﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace EAD_project.Models
{
    public class trainData
    {
        [Required(ErrorMessage="Id is required")]
        [Range(0, int.MaxValue, ErrorMessage = "ID be a positive number")]
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is Required")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Type is Required")]
        public string Type { get; set; }

        [Required(ErrorMessage = "source station is Required")]
        public string Source_station { get; set; }

        [Required(ErrorMessage = "Destination station is Required")]
        public string Destination_station { get; set; }

        [Required(ErrorMessage = "Source id is Requirde")]
        public string Source_Id { get; set; }

        [Required(ErrorMessage = "Destination id is Required")]
        public string Destination_id { get; set; }
    }
}